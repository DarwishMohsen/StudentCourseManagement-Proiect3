﻿using System.ComponentModel.DataAnnotations;

namespace PAW_Project.Models
{
    public class Course
    {
        [Key]
        public int CourseID { get; set; }
        public string Name { get; set; }
        public int Year { get; set; }
        public int Semester { get; set; }

        public ICollection<Professor> Professors { get; set; } = new List<Professor>();
        public ICollection<Studies> StudentEnrollments { get; set; } = new List<Studies>();
        public ICollection<Schedule> Schedules { get; set; } = new List<Schedule>();
    }
}