﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PAW_Project.Models;
using PAW_Project.Services;

namespace PAW_Project.Controllers
{
    public class CoursesController : Controller
    {
        private readonly ICourseService _service;
        private readonly IProfessorService _profService;

        // Injecting both services to keep the architecture clean
        public CoursesController(ICourseService service, IProfessorService profService)
        {
            _service = service;
            _profService = profService;
        }

        public async Task<IActionResult> Index() => View(await _service.GetAllAsync());

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var item = await _service.GetByIdAsync(id.Value);
            return item == null ? NotFound() : View(item);
        }

        // GET: Create
        public async Task<IActionResult> Create()
        {
            // Fetch professors using the service and create the dropdown list
            var professors = await _profService.GetAllAsync();

            // NOTE: Change "ProfessorID" and "LastName" if your properties are named differently in Professor.cs
            ViewData["ProfessorId"] = new SelectList(professors, "ProfessorID", "LastName");
            return View();
        }

        // POST: Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CourseID,Name,Year,Semester,ProfessorId")] Course course)
        {
            if (ModelState.IsValid)
            {
                await _service.CreateAsync(course);
                return RedirectToAction(nameof(Index));
            }

            // If validation fails, we must reload the dropdown list before returning the view
            var professors = await _profService.GetAllAsync();
            ViewData["ProfessorId"] = new SelectList(professors, "ProfessorID", "LastName", course.ProfessorID);
            return View(course);
        }

        // GET: Edit
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var item = await _service.GetByIdAsync(id.Value);
            if (item == null) return NotFound();

            // Load dropdown and set the currently selected professor for this course
            var professors = await _profService.GetAllAsync();
            ViewData["ProfessorId"] = new SelectList(professors, "ProfessorID", "LastName", item.ProfessorID);
            return View(item);
        }

        // POST: Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CourseID,Name,Year,Semester,ProfessorId")] Course course)
        {
            if (id != course.CourseID) return NotFound();

            if (ModelState.IsValid)
            {
                await _service.UpdateAsync(course);
                return RedirectToAction(nameof(Index));
            }

            // Reload dropdown on validation failure
            var professors = await _profService.GetAllAsync();
            ViewData["ProfessorId"] = new SelectList(professors, "ProfessorID", "LastName", course.ProfessorID);
            return View(course);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var item = await _service.GetByIdAsync(id.Value);
            return item == null ? NotFound() : View(item);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}