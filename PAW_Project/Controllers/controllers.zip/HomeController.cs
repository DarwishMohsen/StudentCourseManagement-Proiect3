using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PAW_Project.Data;
using PAW_Project.Models;

namespace PAW_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index() => View();

        public async Task<IActionResult> Cursuri()
        {
            var courses = await _context.Courses
                .Include(c => c.Professors)
                .ToListAsync();
            return View(courses);
        }

        public async Task<IActionResult> Detalii(int? id)
        {
            if (id == null) return RedirectToAction("Cursuri");

            var course = await _context.Courses
                .Include(c => c.Professors)
                .Include(c => c.Schedules)
                    .ThenInclude(s => s.Rooms)
                .FirstOrDefaultAsync(m => m.CourseID == id);

            if (course == null) return NotFound();
            return View(course);
        }

        public IActionResult Inscriere()
        {
            ViewBag.Courses = _context.Courses.ToList();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ProcessInscriere(string cnp, string nume, string prenume, int courseId)
        {
            var student = new Student { SCNP = cnp, LastName = nume, FirstName = prenume, Year = 1, Type = "Regular" };
            _context.Students.Add(student);

            var enrollment = new Studies { SCNP = cnp, CourseID = courseId, Grade = 0 };
            _context.CourseStudies.Add(enrollment);

            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public IActionResult Ghid() => View();
        public IActionResult Despre() => View();
        public IActionResult Contact() => View();
        public IActionResult Faq() => View();
    }
}