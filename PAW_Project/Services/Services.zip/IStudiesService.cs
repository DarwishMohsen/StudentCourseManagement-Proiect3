﻿using PAW_Project.Models;

namespace PAW_Project.Services
{
    public interface IStudiesService
    {
        Task<IEnumerable<Studies>> GetAllStudiesAsync();
        // You can add methods here later like "UpdateGradeAsync" if needed
    }
}