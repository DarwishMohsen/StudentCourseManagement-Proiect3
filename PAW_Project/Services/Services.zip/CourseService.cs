﻿using PAW_Project.Models;
using PAW_Project.Repositories;

namespace PAW_Project.Services
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _repo;

        public CourseService(ICourseRepository repo) => _repo = repo;

        public async Task<IEnumerable<Course>> GetAllAsync() => await _repo.GetAllAsync();

        public async Task<Course> GetByIdAsync(int id) => await _repo.GetByIdAsync(id);

        public async Task CreateAsync(Course course)
        {
            if (string.IsNullOrEmpty(course.Name)) return; // Simple Business Logic
            await _repo.AddAsync(course);
            await _repo.SaveAsync();
        }

        public async Task UpdateAsync(Course course)
        {
            _repo.Update(course);
            await _repo.SaveAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var course = await _repo.GetByIdAsync(id);
            if (course != null)
            {
                _repo.Delete(course);
                await _repo.SaveAsync();
            }
        }
    }
}