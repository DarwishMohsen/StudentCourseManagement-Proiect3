﻿using PAW_Project.Data;
using PAW_Project.Models;

namespace PAW_Project.Repositories
{
    public class CourseRepository : GenericRepository<Course>, ICourseRepository
    {
        public CourseRepository(ApplicationDbContext context) : base(context) { }
    }
}